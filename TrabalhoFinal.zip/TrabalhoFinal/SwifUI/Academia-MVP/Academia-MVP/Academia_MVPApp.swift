//
//  Academia_MVPApp.swift
//  Academia-MVP
//
//  Created by student on 20/04/23.
//

import SwiftUI

@main
struct Academia_MVPApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
