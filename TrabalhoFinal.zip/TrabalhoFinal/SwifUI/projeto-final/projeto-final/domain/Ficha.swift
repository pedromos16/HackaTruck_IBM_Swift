//
//  Ficha.swift
//  projeto-final
//
//  Created by student on 28/04/23.
//

import Foundation

struct Ficha: Hashable {
    var nome: String
    var exercicios: [Exercicio]
}
