//
//  LoginScreenApp.swift
//  LoginScreen
//
//  Created by Federico on 13/11/2021.
//

import SwiftUI

@main
struct LoginScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
