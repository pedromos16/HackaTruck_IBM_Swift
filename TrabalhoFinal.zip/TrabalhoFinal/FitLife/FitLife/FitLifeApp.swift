//
//  FitLifeApp.swift
//  FitLife
//
//  Created by Student15 on 08/05/23.
//

import SwiftUI

@main
struct FitLifeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
