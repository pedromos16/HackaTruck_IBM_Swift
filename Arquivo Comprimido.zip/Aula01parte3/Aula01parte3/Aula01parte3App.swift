//
//  Aula01parte3App.swift
//  Aula01parte3
//
//  Created by Student25 on 05/04/23.
//

import SwiftUI

@main
struct Aula01parte3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
