//
//  Aula01Parte2App.swift
//  Aula01Parte2
//
//  Created by Student25 on 05/04/23.
//

import SwiftUI

@main
struct Aula01Parte2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
