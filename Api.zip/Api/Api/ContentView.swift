//
//  ContentView.swift
//  Api
//
//  Created by Student25 on 14/04/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
        }
        .padding()
    }
}

struct Art : Identifiable{
    var id: ObjectIdentifier?
    
    var title : String
    var artist: String?
    var date : String?
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
