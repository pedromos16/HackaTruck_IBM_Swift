//
//  Aula01TardeApp.swift
//  Aula01Tarde
//
//  Created by Student25 on 05/04/23.
//

import SwiftUI

@main
struct Aula01TardeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
