//
//  ApiApp.swift
//  Api
//
//  Created by Student25 on 14/04/23.
//

import SwiftUI

@main
struct ApiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
