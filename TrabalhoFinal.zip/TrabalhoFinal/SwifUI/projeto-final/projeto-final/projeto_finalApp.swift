//
//  projeto_finalApp.swift
//  projeto-final
//
//  Created by student on 27/04/23.
//

import SwiftUI

@main
struct projeto_finalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
