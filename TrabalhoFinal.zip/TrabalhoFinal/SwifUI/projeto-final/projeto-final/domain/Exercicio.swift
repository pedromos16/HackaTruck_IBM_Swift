//
//  Exercicio.swift
//  projeto-final
//
//  Created by student on 28/04/23.
//

import Foundation

struct Exercicio: Hashable {
    var nome: String
    var series: Int
    var carga: Double
    var anotacao: String
    var foto: String
}
